# Repository installation

Vendor the skill under:

```text
.ai/skills/go-security-audit/
```

Copy the workflow template:

```bash
mkdir -p .github/workflows
cp .ai/skills/go-security-audit/assets/github-actions-audit.yml .github/workflows/audit.yml
```

Create the GitHub Actions repository secret:

```text
OLLAMA_API_KEY
```

Default model:

```text
glm-5.2
```

For the first calibration phase, keep:

```text
AUDIT_FAIL_ON=none
```

Run a local dry-run from the repository root without calling Ollama Cloud:

```bash
AUDIT_DRY_RUN=1 \
AUDIT_RUN_STATIC_CHECKS=false \
bash .ai/skills/go-security-audit/scripts/audit.sh origin/main HEAD
```
