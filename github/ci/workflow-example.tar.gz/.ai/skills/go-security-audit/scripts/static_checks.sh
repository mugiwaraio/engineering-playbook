#!/usr/bin/env bash
set -euo pipefail

OUT_DIR="${1:?usage: static_checks.sh <output-dir>}"
mkdir -p "$OUT_DIR"

run_capture() {
  local name="$1"
  shift
  local outfile="$OUT_DIR/${name}.txt"
  {
    echo '$' "$@"
    "$@"
  } >"$outfile" 2>&1 || {
    local rc=$?
    echo "" >>"$outfile"
    echo "[exit_code=${rc}]" >>"$outfile"
    return 0
  }
}

if command -v go >/dev/null 2>&1; then
  run_capture go-vet go vet ./...
else
  printf '%s\n' '[skipped: go not installed]' >"$OUT_DIR/go-vet.txt"
fi

if command -v govulncheck >/dev/null 2>&1; then
  run_capture govulncheck govulncheck ./...
else
  printf '%s\n' '[skipped: govulncheck not installed]' >"$OUT_DIR/govulncheck.txt"
fi

if command -v gosec >/dev/null 2>&1; then
  run_capture gosec gosec -quiet ./...
else
  printf '%s\n' '[skipped: gosec not installed]' >"$OUT_DIR/gosec.txt"
fi

# Keep hosted-model context bounded. Each tool gets at most 40 KiB of text.
: >"$OUT_DIR/static-context.txt"
for f in "$OUT_DIR/go-vet.txt" "$OUT_DIR/govulncheck.txt" "$OUT_DIR/gosec.txt"; do
  {
    echo "===== $(basename "$f") ====="
    head -c 40960 "$f"
    echo
    echo
  } >>"$OUT_DIR/static-context.txt"
done
