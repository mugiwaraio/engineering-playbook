#!/usr/bin/env python3
"""Normalize and redact likely credential values from a Git diff before cloud review."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


PEM_RE = re.compile(
    r"-----BEGIN ((?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY)-----.*?-----END \1-----",
    re.DOTALL,
)

PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("aws_access_key", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("github_token", re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b")),
    ("slack_token", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b")),
    ("jwt", re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b")),
    (
        "generic_secret_assignment",
        re.compile(
            r"(?i)(?P<prefix>\b(?:api[_-]?key|access[_-]?token|auth[_-]?token|secret|client[_-]?secret|password|passwd|private[_-]?key)\b\s*[:=]\s*[\"']?)"
            r"(?P<value>[^\s\"']{8,})"
        ),
    ),
]


def redact(text: str) -> tuple[str, dict[str, int]]:
    counts: dict[str, int] = {}

    def pem_sub(match: re.Match[str]) -> str:
        counts["pem_private_material"] = counts.get("pem_private_material", 0) + 1
        label = match.group(1)
        return f"-----BEGIN {label}-----\n[REDACTED_POSSIBLE_SECRET:PEM] \n-----END {label}-----"

    text = PEM_RE.sub(pem_sub, text)

    for name, pattern in PATTERNS:
        if name == "generic_secret_assignment":
            def generic_sub(match: re.Match[str], *, _name: str = name) -> str:
                value = match.group("value")
                if value.startswith("[REDACTED_POSSIBLE_SECRET:"):
                    return match.group(0)
                counts[_name] = counts.get(_name, 0) + 1
                return f"{match.group('prefix')}[REDACTED_POSSIBLE_SECRET:{_name}]"

            text = pattern.sub(generic_sub, text)
        else:
            def simple_sub(match: re.Match[str], *, _name: str = name) -> str:
                counts[_name] = counts.get(_name, 0) + 1
                return f"[REDACTED_POSSIBLE_SECRET:{_name}]"

            text = pattern.sub(simple_sub, text)

    return text, counts


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--metadata", required=True, type=Path)
    args = parser.parse_args()

    raw = args.input.read_text(encoding="utf-8", errors="replace")
    cleaned = raw.replace("\x00", "[NUL]")
    redacted, counts = redact(cleaned)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(redacted, encoding="utf-8")

    metadata = {
        "input_bytes": len(raw.encode("utf-8")),
        "output_bytes": len(redacted.encode("utf-8")),
        "redaction_count": sum(counts.values()),
        "redactions": counts,
    }
    args.metadata.write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
