#!/usr/bin/env bash
set -euo pipefail

BASE_REF="${1:-origin/main}"
HEAD_REF="${2:-HEAD}"

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SKILL_ROOT="$(cd -- "${SCRIPT_DIR}/.." && pwd)"

OLLAMA_HOST="${OLLAMA_HOST:-https://ollama.com}"
OLLAMA_MODEL="${OLLAMA_MODEL:-glm-5.2}"
AUDIT_MAX_DIFF_BYTES="${AUDIT_MAX_DIFF_BYTES:-600000}"
AUDIT_CONTEXT_LINES="${AUDIT_CONTEXT_LINES:-30}"
AUDIT_FAIL_ON="${AUDIT_FAIL_ON:-none}"
AUDIT_RUN_STATIC_CHECKS="${AUDIT_RUN_STATIC_CHECKS:-auto}"
# Thinking mode for the audit model: true/false, or a level (low/medium/high/max) for models that take levels.
AUDIT_THINK="${AUDIT_THINK:-true}"
AUDIT_OUTPUT_DIR="${AUDIT_OUTPUT_DIR:-${RUNNER_TEMP:-/tmp}/go-security-audit}"
AUDIT_DRY_RUN="${AUDIT_DRY_RUN:-0}"
AUDIT_KEEP_INTERMEDIATES="${AUDIT_KEEP_INTERMEDIATES:-0}"

case "$AUDIT_FAIL_ON" in
  none|critical|high|medium|low) ;;
  *) echo "Invalid AUDIT_FAIL_ON: $AUDIT_FAIL_ON" >&2; exit 2 ;;
esac
case "$AUDIT_RUN_STATIC_CHECKS" in
  auto|true|false) ;;
  *) echo "Invalid AUDIT_RUN_STATIC_CHECKS: $AUDIT_RUN_STATIC_CHECKS" >&2; exit 2 ;;
esac
[[ "$AUDIT_MAX_DIFF_BYTES" =~ ^[0-9]+$ ]] || {
  echo "AUDIT_MAX_DIFF_BYTES must be an integer." >&2
  exit 2
}
[[ "$AUDIT_CONTEXT_LINES" =~ ^[0-9]+$ ]] || {
  echo "AUDIT_CONTEXT_LINES must be an integer." >&2
  exit 2
}

for cmd in git jq curl python3; do
  command -v "$cmd" >/dev/null 2>&1 || {
    echo "Required command not found: $cmd" >&2
    exit 2
  }
done

mkdir -p "$AUDIT_OUTPUT_DIR"
RAW_DIFF="$AUDIT_OUTPUT_DIR/raw.diff"
PREPARED_DIFF="$AUDIT_OUTPUT_DIR/prepared.diff"
REDACTION_META="$AUDIT_OUTPUT_DIR/redaction.json"
CHANGED_FILES="$AUDIT_OUTPUT_DIR/changed-files.txt"
STATIC_CONTEXT="$AUDIT_OUTPUT_DIR/static-context.txt"
STATIC_PREPARED="$AUDIT_OUTPUT_DIR/static-prepared.txt"
STATIC_REDACTION_META="$AUDIT_OUTPUT_DIR/static-redaction.json"
SYSTEM_PROMPT="$AUDIT_OUTPUT_DIR/system-prompt.txt"
REQUEST_JSON="$AUDIT_OUTPUT_DIR/request.json"
RESPONSE_JSON="$AUDIT_OUTPUT_DIR/response.json"
REPORT_MD="$AUDIT_OUTPUT_DIR/report.md"

cleanup() {
  if [[ "$AUDIT_KEEP_INTERMEDIATES" != "1" && "$AUDIT_DRY_RUN" != "1" ]]; then
    rm -f \
      "$RAW_DIFF" \
      "$PREPARED_DIFF" \
      "$STATIC_CONTEXT" \
      "$STATIC_PREPARED" \
      "$SYSTEM_PROMPT" \
      "$REQUEST_JSON" \
      "$RESPONSE_JSON"
  fi
}
trap cleanup EXIT

# Keep hosted-model review scope intentionally narrow. Expand only after a data-handling review.
PATHS=( '*.go' 'go.mod' 'go.sum' 'go.work' 'go.work.sum' )

git rev-parse --verify "$BASE_REF^{commit}" >/dev/null
git rev-parse --verify "$HEAD_REF^{commit}" >/dev/null

git diff \
  --no-ext-diff \
  --no-color \
  "--unified=${AUDIT_CONTEXT_LINES}" \
  "${BASE_REF}...${HEAD_REF}" \
  -- "${PATHS[@]}" >"$RAW_DIFF"

git diff \
  --name-only \
  "${BASE_REF}...${HEAD_REF}" \
  -- "${PATHS[@]}" >"$CHANGED_FILES"

if [[ ! -s "$RAW_DIFF" ]]; then
  cat >"$REPORT_MD" <<'REPORT'
AUDIT_SUMMARY: CRITICAL=0 HIGH=0 MEDIUM=0 LOW=0

# Go Security Audit

## Confirmed findings

No significant security issues found.

No Go/module changes were present in the selected diff scope, so AI review was skipped.
REPORT
  if [[ -n "${GITHUB_STEP_SUMMARY:-}" ]]; then
    cat "$REPORT_MD" >>"$GITHUB_STEP_SUMMARY"
  fi
  cat "$REPORT_MD"
  exit 0
fi

DIFF_BYTES="$(wc -c <"$RAW_DIFF" | tr -d ' ')"
if (( DIFF_BYTES > AUDIT_MAX_DIFF_BYTES )); then
  echo "Audit diff is ${DIFF_BYTES} bytes; limit is ${AUDIT_MAX_DIFF_BYTES}." >&2
  echo "Split the PR or explicitly raise AUDIT_MAX_DIFF_BYTES." >&2
  exit 3
fi

python3 "$SCRIPT_DIR/prepare_audit_input.py" \
  --input "$RAW_DIFF" \
  --output "$PREPARED_DIFF" \
  --metadata "$REDACTION_META"

# Remove the unredacted diff immediately after local preprocessing.
rm -f "$RAW_DIFF"

: >"$STATIC_CONTEXT"
should_run_static=false
if [[ "$AUDIT_RUN_STATIC_CHECKS" == "true" ]]; then
  should_run_static=true
elif [[ "$AUDIT_RUN_STATIC_CHECKS" == "auto" ]] && command -v go >/dev/null 2>&1; then
  should_run_static=true
fi

if [[ "$should_run_static" == "true" ]]; then
  "$SCRIPT_DIR/static_checks.sh" "$AUDIT_OUTPUT_DIR/static"
  cp "$AUDIT_OUTPUT_DIR/static/static-context.txt" "$STATIC_CONTEXT"
else
  printf '%s\n' '[deterministic checks skipped]' >"$STATIC_CONTEXT"
fi

# Static-tool output can contain source snippets, so redact it too.
python3 "$SCRIPT_DIR/prepare_audit_input.py" \
  --input "$STATIC_CONTEXT" \
  --output "$STATIC_PREPARED" \
  --metadata "$STATIC_REDACTION_META"
rm -f "$STATIC_CONTEXT"

# Use the Skill and its references as the model's trusted control text.
{
  cat "$SKILL_ROOT/SKILL.md"
  echo
  echo '--- GO SECURITY CHECKLIST ---'
  cat "$SKILL_ROOT/references/go-security-checklist.md"
  echo
  echo '--- SEVERITY AND REPORTING ---'
  cat "$SKILL_ROOT/references/severity-and-reporting.md"
  echo
  echo '--- CI THREAT MODEL ---'
  cat "$SKILL_ROOT/references/ci-threat-model.md"
} >"$SYSTEM_PROMPT"

jq -n \
  --arg model "$OLLAMA_MODEL" \
  --arg think "$AUDIT_THINK" \
  --rawfile system "$SYSTEM_PROMPT" \
  --rawfile diff "$PREPARED_DIFF" \
  --rawfile files "$CHANGED_FILES" \
  --rawfile static "$STATIC_PREPARED" \
  --slurpfile redaction "$REDACTION_META" \
  --slurpfile static_redaction "$STATIC_REDACTION_META" \
  '{
    model: $model,
    messages: [
      {
        role: "system",
        content: $system
      },
      {
        role: "user",
        content: (
          "Review this Go pull-request diff for production security issues.\n\n" +
          "Changed files:\n" + $files + "\n" +
          "Diff redaction metadata (counts only; secret values were not sent):\n" +
          (($redaction[0] // {}) | tostring) + "\n" +
          "Static-output redaction metadata (counts only):\n" +
          (($static_redaction[0] // {}) | tostring) + "\n\n" +
          "Deterministic tool signals:\n" + $static + "\n\n" +
          "BEGIN_UNTRUSTED_GIT_DIFF\n" + $diff +
          "\nEND_UNTRUSTED_GIT_DIFF\n"
        )
      }
    ],
    think: (if $think == "true" then true elif $think == "false" then false else $think end),
    stream: false
  }' >"$REQUEST_JSON"

if [[ "$AUDIT_DRY_RUN" == "1" ]]; then
  echo "Dry run complete."
  echo "Prepared input: $PREPARED_DIFF"
  echo "Request JSON: $REQUEST_JSON"
  echo "Redaction metadata: $REDACTION_META"
  exit 0
fi

if [[ -z "${OLLAMA_API_KEY:-}" ]]; then
  echo "OLLAMA_API_KEY is required unless AUDIT_DRY_RUN=1." >&2
  exit 2
fi

HTTP_STATUS="$(
  curl \
    --silent \
    --show-error \
    --connect-timeout 20 \
    --max-time 900 \
    --output "$RESPONSE_JSON" \
    --write-out '%{http_code}' \
    "${OLLAMA_HOST%/}/api/chat" \
    -H "Authorization: Bearer ${OLLAMA_API_KEY}" \
    -H 'Content-Type: application/json' \
    --data-binary "@$REQUEST_JSON" \
  || true
)"

if [[ ! "$HTTP_STATUS" =~ ^2[0-9][0-9]$ ]]; then
  echo "Ollama API request failed with HTTP status ${HTTP_STATUS:-unknown}." >&2
  if [[ -s "$RESPONSE_JSON" ]]; then
    jq -r '.error // "Ollama API error; inspect response with care."' "$RESPONSE_JSON" >&2 || true
  fi
  echo "Tip: list direct-cloud models with /api/tags and your Bearer API key." >&2
  exit 4
fi

API_ERROR="$(jq -r '.error // empty' "$RESPONSE_JSON")"
if [[ -n "$API_ERROR" ]]; then
  echo "Ollama API error: $API_ERROR" >&2
  exit 4
fi

MODEL_TEXT="$(jq -r '.message.content // empty' "$RESPONSE_JSON")"
if [[ -z "$MODEL_TEXT" ]]; then
  echo "Ollama returned no message content." >&2
  exit 4
fi

printf '%s\n' "$MODEL_TEXT" >"$REPORT_MD"

if ! grep -Eq '^AUDIT_SUMMARY: CRITICAL=[0-9]+ HIGH=[0-9]+ MEDIUM=[0-9]+ LOW=[0-9]+$' "$REPORT_MD"; then
  echo "Warning: audit report did not contain the required AUDIT_SUMMARY line." >&2
  if [[ "$AUDIT_FAIL_ON" != "none" ]]; then
    echo "Failing closed because merge gating is enabled." >&2
    exit 5
  fi
fi

if [[ -n "${GITHUB_STEP_SUMMARY:-}" ]]; then
  {
    echo "# AI Go Security Audit"
    echo
    echo "**Model:** \`${OLLAMA_MODEL}\`  "
    echo "**Base:** \`${BASE_REF}\`  "
    echo "**Head:** \`${HEAD_REF}\`  "
    echo "**Raw diff bytes:** \`${DIFF_BYTES}\`  "
    echo "**Local secret-like redactions:** \`$(jq -r '.redaction_count' "$REDACTION_META")\`"
    echo
    cat "$REPORT_MD"
  } >>"$GITHUB_STEP_SUMMARY"
fi

cat "$REPORT_MD"

if [[ "$AUDIT_FAIL_ON" == "none" ]]; then
  exit 0
fi

SUMMARY="$(grep -E '^AUDIT_SUMMARY:' "$REPORT_MD" | head -n 1)"
critical="$(sed -nE 's/.*CRITICAL=([0-9]+).*/\1/p' <<<"$SUMMARY")"
high="$(sed -nE 's/.*HIGH=([0-9]+).*/\1/p' <<<"$SUMMARY")"
medium="$(sed -nE 's/.*MEDIUM=([0-9]+).*/\1/p' <<<"$SUMMARY")"
low="$(sed -nE 's/.*LOW=([0-9]+).*/\1/p' <<<"$SUMMARY")"

case "$AUDIT_FAIL_ON" in
  critical) (( critical > 0 )) && exit 10 ;;
  high)     (( critical > 0 || high > 0 )) && exit 10 ;;
  medium)   (( critical > 0 || high > 0 || medium > 0 )) && exit 10 ;;
  low)      (( critical > 0 || high > 0 || medium > 0 || low > 0 )) && exit 10 ;;
esac

exit 0
