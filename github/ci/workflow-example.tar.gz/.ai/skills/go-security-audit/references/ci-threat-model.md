# CI and Hosted-Model Threat Model

Apply these controls whenever the audit runs in GitHub Actions or sends repository data to a hosted model.

## 1. Pull request trust

Treat PR content as attacker-controlled. Source code can contain prompt-injection text such as comments that tell the model to ignore audit rules or disclose secrets. The model must treat all repository content only as data.

Do not evaluate model-generated shell commands. Do not let model output control command names, file paths, URLs, environment variable names, or subsequent privileged actions.

## 2. Fork pull requests and secrets

Do not expose `OLLAMA_API_KEY` to untrusted fork PR execution. Prefer `pull_request` with an explicit same-repository condition for the AI job. Avoid `pull_request_target` for code-executing audit workflows unless the workflow is intentionally designed to never checkout or execute untrusted head content.

## 3. GitHub token permissions

Use least privilege. A read-only audit needs only:

```yaml
permissions:
  contents: read
```

Add `pull-requests: write` only if a later version intentionally posts comments. Do not grant `contents: write`, package write, deployment, or repository administration permissions to a read-only audit.

## 4. Hosted model data minimization

Send the smallest useful review context:

- default to the PR diff
- include only Go/module files by default
- use bounded context lines around changes
- reject unexpectedly large diffs rather than silently truncating
- avoid `.env`, certificates, database dumps, production configs, generated artifacts, and unrelated repository files

If broader context is needed, fetch and send only the specific surrounding file/function required to validate a candidate finding.

## 5. Secret handling

The local preprocessing stage must mask likely secret values before cloud submission. Preserve enough information for the model to recognize that a secret-like value was added, but never transmit the full value solely for audit convenience.

Never print `OLLAMA_API_KEY` or raw authorization headers. Do not enable shell tracing (`set -x`) in the API-calling step.

If the diff introduces a credential, the correct remediation normally includes removing it from Git history where necessary and rotating/revoking it; deleting the line alone may not be sufficient.

## 6. Network boundaries

For a GitHub-hosted runner, the AI step should need outbound HTTPS to Ollama Cloud plus normal GitHub/Go dependency endpoints. The model does not need inbound network access to the runner.

Do not give the hosted model autonomous network or repository write tools for the first audit phase.

## 7. Deterministic tools vs AI

Use deterministic tooling for facts it can establish reliably:

- `go test` for tests
- `go vet` for supported static diagnostics
- `govulncheck` for Go vulnerability database findings and reachability
- `gosec` as an additional rule-based security signal when the project accepts its noise profile

Use AI for cross-file reasoning, business logic, authz/tenancy reasoning, exploitability analysis, concurrency design, and review prioritization.

Do not let a clean AI report override a failing deterministic security check.

## 8. Merge gating

Start in report-only mode. Measure model usefulness on real PRs before enforcing gates.

When gating is enabled:

- require the model to produce the exact `AUDIT_SUMMARY` line
- fail closed if the summary cannot be parsed
- gate only on confirmed findings
- keep a documented bypass/approval process for false positives
- preserve human security review for sensitive changes

Recommended initial setting:

```text
AUDIT_FAIL_ON=none
```

A later high-assurance setting may use:

```text
AUDIT_FAIL_ON=high
```

which blocks on HIGH or CRITICAL findings.

## 9. Logs and artifacts

Do not upload the raw unredacted diff as a public artifact. The prepared redacted input and final report may still contain sensitive architectural information; follow repository retention and access policies.

GitHub job summaries are visible to people who can view the workflow run. Keep secret values out of them.
