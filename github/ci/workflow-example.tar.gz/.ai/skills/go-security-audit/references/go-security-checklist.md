# Go Security Review Checklist

Use this checklist as a review aid, not as a requirement to manufacture findings. Only report an issue when the changed code and relevant context support it.

## 1. Authentication and identity

Check whether changed code:

- verifies token signatures before trusting claims
- validates issuer, audience, expiry, not-before, token type, and intended purpose where relevant
- prevents algorithm confusion and accepts only intended signing methods
- distinguishes access, refresh, reset, invite, and verification tokens
- invalidates or rotates sessions and refresh tokens correctly
- protects password-reset and account-recovery flows against replay and enumeration
- uses constant-time comparison for secrets/MACs where timing is relevant
- uses secure cookie flags (`Secure`, `HttpOnly`, appropriate `SameSite`) when cookies carry credentials
- avoids authentication decisions based only on client-controlled headers
- handles reverse-proxy identity headers only from trusted proxies

## 2. Authorization, ownership, and tenancy

Check for:

- missing authorization after authentication
- IDOR / object ownership bypass
- horizontal or vertical privilege escalation
- tenant ID derived from request input instead of trusted identity context
- queries or updates missing tenant/owner predicates
- middleware applied to one route but omitted from an equivalent route
- admin/debug/internal endpoints exposed through public routing
- confused-deputy behavior when a service acts on behalf of a caller
- authorization performed before canonicalization or after a security-sensitive action
- batch operations that validate only one item but operate on many

Trace authorization to the actual data access or side effect. Do not assume a route is protected merely because a middleware exists elsewhere.

## 3. Input validation and parsing

Review attacker-controlled input from HTTP, RPC, queues, events, files, CLI arguments, environment variables, and external services.

Check for:

- missing length/range/cardinality limits
- integer overflow, underflow, signedness, or narrowing assumptions
- unsafe parsing with ignored errors
- duplicate-key or ambiguous parsing behavior
- validation before normalization when normalization can change meaning
- Unicode/case/canonicalization inconsistencies in security decisions
- unbounded JSON, multipart, archive, decompression, or protobuf processing
- regex patterns vulnerable to excessive resource use
- panic paths reachable from untrusted input

## 4. SQL, storage, and query construction

Check for:

- SQL built with string concatenation or `fmt.Sprintf` using untrusted data
- unsafe dynamic identifiers without an explicit allowlist
- missing tenant/owner condition in SELECT/UPDATE/DELETE
- mass assignment or updating fields a caller should not control
- race-prone read-then-write flows that require a transaction or conditional update
- transaction errors ignored or rollback/commit semantics mishandled
- secrets or sensitive records stored without appropriate protection
- queries that expose timing or enumeration differences on sensitive objects

Parameterized values do not automatically make dynamic table/column/order expressions safe.

## 5. Command execution and process control

Audit `os/exec`, shell invocation, interpreters, build tools, archive tools, and external utilities.

Check for:

- `sh -c`, `bash -c`, PowerShell, or equivalent with attacker-controlled fragments
- untrusted executable paths or PATH search
- arguments interpreted as options when leading `-` is possible
- environment-variable injection affecting child process behavior
- inherited credentials or secrets unnecessarily exposed to child processes
- missing timeouts/cancellation for external commands

Prefer direct argv execution and explicit allowlists.

## 6. SSRF and outbound requests

Check URL, host, scheme, redirect, proxy, DNS, and destination handling.

Look for:

- arbitrary user-controlled outbound URLs
- access to loopback, link-local, RFC1918/private ranges, metadata endpoints, or internal DNS
- allowlists checked before redirects but not after redirects
- DNS rebinding / resolution mismatch between validation and connection
- userinfo or parsing ambiguity in URLs
- unsafe custom `DialContext`, proxy, or transport behavior
- missing request deadlines

## 7. Filesystem and path security

Audit `os.Open*`, `os.Create*`, `os.Remove*`, `os.Rename`, archive extraction, uploads, temp files, and symlinks.

Check for:

- path traversal (`..`, absolute paths, encoded separators)
- validation based only on string prefixes rather than canonical path containment
- symlink/hardlink abuse
- archive traversal (zip-slip/tar-slip)
- insecure permissions on secrets or generated credentials
- predictable sensitive temp files
- TOCTOU between validation and use
- overwrite/clobber behavior on attacker-selected paths

## 8. HTTP server and API hardening

Review:

- server read/write/idle/header timeouts
- request body limits
- multipart limits
- CORS decisions, especially credentials + broad origins
- trusted proxy / forwarded header configuration
- redirect targets
- cache controls for sensitive responses
- content type and attachment behavior for user-controlled data
- debug/profiling endpoints
- error responses that reveal internals or secrets

Do not report absence of a control when it is clearly enforced by infrastructure outside the changed code unless the review scope establishes otherwise.

## 9. Cryptography, signatures, and randomness

Check for:

- `math/rand` used for tokens, nonces, reset codes, secrets, or security decisions
- weak/deprecated hashes or ciphers in security-sensitive use
- ECB or unauthenticated encryption
- nonce/IV reuse
- signature verification omitted or performed on the wrong canonical bytes
- MAC/signature comparisons performed unsafely
- keys embedded in source or logs
- TLS verification disabled (`InsecureSkipVerify`) without tightly justified pinning logic
- custom cryptography replacing standard libraries/protocols

## 10. Secrets and sensitive data

Check for:

- hard-coded API keys, passwords, private keys, JWTs, cloud credentials, webhook secrets
- credentials included in URLs, logs, panic messages, traces, metrics, or error responses
- full request/response bodies logged on authentication/payment/PII paths
- secrets retained in generated artifacts or test fixtures that ship to production
- insecure secret defaults used when environment variables are absent

A redaction marker in CI input can itself be evidence that a probable secret was introduced; verify the original diff locally before reporting the exact type.

## 11. Concurrency and Go-specific correctness with security impact

Review goroutines, channels, mutexes, atomics, maps, caches, pools, contexts, and lifecycle management.

Check for:

- concurrent map read/write
- race on authorization/session/cache state
- check-then-act races
- goroutine leaks on abandoned channels or missing cancellation
- deadlocks from lock ordering or channel cycles
- send on closed channel / double close paths
- WaitGroup misuse
- loop-variable capture bugs (consider the project's Go version semantics)
- background work detached from request cancellation without bounded lifecycle
- unbounded goroutine creation from attacker-controlled input
- data returned to pools while still referenced

Only elevate concurrency issues to security findings when they can cause bypass, corruption, leakage, crash/DoS, or trust-boundary failures.

## 12. Resource exhaustion and availability

Check for attacker-controlled:

- unbounded loops or retries
- recursion/decompression/regex cost
- memory allocation or buffer growth
- goroutine, connection, file descriptor, queue, or worker growth
- fan-out to downstream services
- expensive database queries without limits
- file uploads without size quotas
- timeouts omitted on network/database/process calls

Consider whether rate limiting exists elsewhere before claiming an exploitable DoS.

## 13. Error handling and failure modes

Check for:

- ignored errors that change security behavior
- fail-open authorization/authentication paths
- partial success that commits a sensitive side effect after an error
- deferred close/rollback ordering mistakes
- panics exposing availability or secrets
- retrying non-idempotent operations
- returning internal errors or secrets to clients

## 14. Serialization, reflection, templates, and unsafe boundaries

Review:

- `html/template` vs `text/template` in web output
- unsafe construction of templates from untrusted content
- reflection/type assertions that can panic on untrusted data
- `unsafe` and cgo memory/lifetime assumptions
- untrusted binary/text decoding with unbounded sizes
- polymorphic or plugin loading controlled by external input

## 15. Dependencies and supply chain

For `go.mod`, `go.sum`, and toolchain changes:

- use `govulncheck` for reachable known vulnerabilities
- examine unexpected new modules or replacements
- scrutinize `replace` directives, local paths, forks, and pseudo-versions
- verify security-sensitive dependency upgrades/downgrades are intentional
- consider module provenance and maintenance risk when a new critical dependency appears

Do not infer a known vulnerability from version memory alone; use deterministic vulnerability data when available.

## 16. Business logic and state transitions

Look beyond language-level bugs. Review:

- double-submit / replay / idempotency failures
- balance, quota, inventory, entitlement, or state-transition invariants
- stale-state authorization decisions
- workflows that can skip required approval or verification steps
- payment/webhook signature and replay handling
- out-of-order event handling
- privileged operations triggered before durable authorization/state checks
- TOCTOU between eligibility checks and mutations

State the violated invariant explicitly in the finding.
