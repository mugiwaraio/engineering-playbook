# Severity and Reporting Policy

## Evidence threshold

Classify each candidate as one of:

- **Confirmed**: the code and reachable context support the vulnerability and impact.
- **Needs manual verification**: a plausible security concern exists but required context is outside the review input.
- **Not a finding**: style, generic hardening, unreachable speculation, or a pattern already mitigated by visible controls.

Only Confirmed items count in `AUDIT_SUMMARY`.

## Severity rubric

### CRITICAL

Use only when exploitation can plausibly cause immediate, severe compromise such as unauthenticated remote code execution, broad authentication bypass, compromise of highly sensitive secrets at scale, catastrophic cross-tenant compromise, or an equivalent business-critical failure with low exploitation friction.

### HIGH

Use for a clearly exploitable vulnerability with substantial impact, such as serious authorization bypass, privilege escalation, sensitive-data exposure, injection reaching a dangerous sink, or repeatable high-impact integrity/availability compromise.

### MEDIUM

Use for a meaningful vulnerability requiring realistic prerequisites, narrower scope, user interaction, limited privileges, or environmental conditions, while still crossing a security boundary or causing material confidentiality/integrity/availability impact.

### LOW

Use for limited-impact, difficult-to-exploit, or defense-in-depth weaknesses with a concrete security consequence. Do not use LOW as a bucket for style or generic best practices.

## Confidence rules

- Do not raise severity to compensate for low confidence.
- Do not report a vulnerability solely because a dangerous API is present.
- Trace attacker control to the sink or security decision.
- Check relevant validation, middleware, query predicates, context propagation, and error paths.
- When a key assumption cannot be verified, label the item `Needs manual verification` and exclude it from summary counts.

## Output language

- Write the entire report body in Simplified Chinese, including section headings, finding titles, and all explanatory text.
- Keep the `AUDIT_SUMMARY` line and the severity labels (CRITICAL / HIGH / MEDIUM / LOW) in their exact English format; they are machine-parsed and must not be translated.
- Keep file paths, code identifiers, Go symbols, and tool names as-is.

## Required report format

Start with exactly one summary line:

```text
AUDIT_SUMMARY: CRITICAL=<n> HIGH=<n> MEDIUM=<n> LOW=<n>
```

Then write:

```markdown
# Go Security Audit

## Executive summary

One concise paragraph describing scope, overall risk, and the most important result.

## Confirmed findings

### [HIGH] Short, specific title

**Severity:** HIGH  
**Confidence:** High  
**File:** `internal/example/file.go`  
**Line:** 123  
**Category:** Authorization

#### Problem
Describe the exact defect and the failed security control.

#### Evidence
Quote or paraphrase only the minimum relevant changed logic. Explain attacker control and reachability.

#### Security impact
Describe realistic confidentiality, integrity, availability, or trust-boundary impact.

#### Attack scenario
Give a short, concrete exploitation sequence.

#### Recommended fix
Provide an implementation-oriented Go remediation. Prefer standard-library or established project patterns.

## Needs manual verification

List only plausible concerns that could not be confirmed from available context. Explain exactly what must be checked. Omit this section if empty.

## Positive security observations

Optionally note meaningful security controls in the changed code when they help reviewers understand residual risk. Keep this short.

## Deterministic tool signals

Summarize relevant `go vet`, `govulncheck`, or `gosec` signals if provided. Do not duplicate the same issue as an AI finding unless additional exploit reasoning adds value.
```

If there are no confirmed findings, use zero counts and state under `## Confirmed findings`:

```text
No significant security issues found.
```

## Reporting constraints

- Never include secret values, API keys, private keys, session tokens, or full credentials in the report.
- If a secret appears to be committed, describe its type/location and instruct rotation; redact the value.
- Avoid long code reproduction. Reference the file/line and describe the dangerous logic.
- Separate deterministic scanner output from AI interpretation.
- Do not claim a CVE unless a deterministic source identifies it.
